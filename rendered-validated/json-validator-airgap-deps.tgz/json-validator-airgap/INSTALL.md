# json-validator dependencies for the air-gapped Maven mirror

Adds Camel's JSON Schema validation component (`camel:json-validator`) to the
offline Maven mirror so the operator can build the `schema-validate-*` routes
(and any route with `validate.enabled`) without internet.

## Contents

`m2-overlay.tgz` — a Maven-repo (`m2`) layout overlay with the json-validator
closure, taken verbatim from a mirror that builds these routes successfully:

| Artifact | Version |
|---|---|
| `org.apache.camel.quarkus:camel-quarkus-json-validator` (+ `-deployment`) | 3.15.3 |
| `org.apache.camel:camel-json-validator` | 4.8.5 |
| `com.networknt:json-schema-validator` | 1.5.1 |
| `com.ethlo.time:itu` | 1.10.2 |

Pure Java — no native/arch-specific jars, so it works on any target arch.
Jackson and slf4j deps are already in every Camel mirror and are not included.

## Install (on the air-gapped node)

The mirror serves from `/opt/maven-repo/m2` (nginx docroot, hostPath). Extract
the overlay onto it — nginx serves new files immediately, **no restart**:

```bash
sudo tar -C /opt/maven-repo/m2 -xzf m2-overlay.tgz
# or run the helper:  sudo ./install.sh [/opt/maven-repo/m2]
```

Verify:

```bash
ls /opt/maven-repo/m2/org/apache/camel/quarkus/camel-quarkus-json-validator/3.15.3/
```

Then deploy the routes: `kubectl apply -f schema-validate-http.yaml` (etc.).
The first build fetches these artifacts from the mirror; watch with
`kubectl logs -n camel-k deploy/maven-mirror -f`. Any 404 on a `.jar`/`.pom`
names an artifact still missing (404s on `maven-metadata.xml` are normal).

> If your mirror storage isn't a node hostPath (e.g. a PVC), copy instead into
> the running pod: `kubectl cp m2-overlay.tgz camel-k/<maven-mirror-pod>:/tmp/`
> then `kubectl exec ... -- tar -C /usr/share/nginx/html -xzf /tmp/m2-overlay.tgz`.
