#!/bin/sh
# Extend the offline Maven mirror with the json-validator closure.
# Usage: sudo ./install.sh [MIRROR_M2_DIR]   (default: /opt/maven-repo/m2)
set -e
M2="${1:-/opt/maven-repo/m2}"
HERE="$(cd "$(dirname "$0")" && pwd)"

if [ ! -d "$M2" ]; then
  echo "ERROR: mirror repo dir '$M2' not found." >&2
  echo "Pass the correct path, or if the mirror uses a pod volume see INSTALL.md." >&2
  exit 1
fi

echo "Extracting json-validator artifacts into $M2 ..."
tar -C "$M2" -xzf "$HERE/m2-overlay.tgz"

echo "Done. Verifying:"
ls "$M2/org/apache/camel/quarkus/camel-quarkus-json-validator/3.15.3/" \
   "$M2/org/apache/camel/camel-json-validator/4.8.5/" \
   "$M2/com/networknt/json-schema-validator/1.5.1/" \
   "$M2/com/ethlo/time/itu/1.10.2/"
echo "nginx serves these immediately — no mirror restart needed."
